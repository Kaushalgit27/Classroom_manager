package com.ty.project.presentation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresentationApplicationTests {

	@Test
	void contextLoads() {
	}

}
