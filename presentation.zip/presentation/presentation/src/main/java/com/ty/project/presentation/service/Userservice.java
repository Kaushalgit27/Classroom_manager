package com.ty.project.presentation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.project.presentation.controller.Usercontroller;
import com.ty.project.presentation.dto.Userdto;
import com.ty.project.presentation.entity.Presentation;
import com.ty.project.presentation.entity.User;
import com.ty.project.presentation.enums.Role;
import com.ty.project.presentation.enums.Status;
import com.ty.project.presentation.exception.UsernotfoundException;
import com.ty.project.presentation.repository.Presentationrepository;
import com.ty.project.presentation.repository.Userrepository;

@Service
public class Userservice {
	
	Userrepository userrepository;
	Presentationrepository prepo;
	public Userservice(Userrepository userrepository,Presentationrepository prepo) {
		this.userrepository= userrepository;
		this.prepo=prepo;
	}

	public boolean registration(User userrequest) {
		double totalscore=0;
		Optional<User> opt= userrepository.findByEmail(userrequest.getEmail());
		
		    userrequest.setUserscore(totalscore);
		
		
		if(opt.isPresent()) {
			return false;
			
		}
		else {
			 userrequest.setUserscore(totalscore);
			
			User createuser=new User();
			BeanUtils.copyProperties(userrequest, createuser);
			userrepository.save(createuser);
			return true;
			
		}	
		
	}

	//my logic for login
//	public ResponseEntity<String> logIn(String email, String password) {
//	Optional<User> opt=userrepository.findByEmail(email);
//	if(opt.isPresent()) {
//		User passuser=opt.get();
//		if(passuser.getPassword().equals(password)) {
//			return  new ResponseEntity<String>("Login Successful", HttpStatus.OK);
//		}
//		else {
//			return  ResponseEntity.badRequest().body("Wrong password");
//			
//		}
//	}else {
//		return ResponseEntity.badRequest().body("Wrong email");
//	}
//		
//	}
	
	
	//sir logic using exception
	public boolean logIn(String email,String password) {
		User userfind=userrepository.findByEmail(email).orElseThrow(() -> new UsernotfoundException("User is not register"));
		
		if(userfind.getPassword().equals(password)) {
			return true;
		}else {
			return false;
		}
		
	}
	
	//getting all data by admin

	public List<User> getalldatas() {
		return userrepository.findAll();
		
	}
	
	//updating status by admin

	public ResponseEntity<String> Changestatus(int uid) {
	
		
		
				User userfindbyid=userrepository.findById(uid).orElseThrow(() -> new UsernotfoundException("User is not register"));
				
				Status stat= userfindbyid.getStatus();
				
				if(stat.equals(Status.ACTIVE)) {
					 userfindbyid.setStatus(Status.INACTIVE);
					
				}
				else {
					 userfindbyid.setStatus(Status.ACTIVE);
				}	
				
				userrepository.save( userfindbyid);
				return new ResponseEntity<String>("Status is updated", HttpStatus.OK);
				
		
			
	
	
	
		
	}

	//getting data for user
	public Userdto getdatas(int uid) {
		User user=userrepository.findById(uid).orElseThrow(() -> new UsernotfoundException("User is not register"));
		if(user.getStatus().equals(Status.ACTIVE)) {
			Userdto userdto=new Userdto();
			BeanUtils.copyProperties(user, userdto);
			return userdto;
			
		}else {
			return null;
		}
		
	}
//getting role
	public Role gettingtherole(String email) {
      User user=userrepository.findByEmail(email).orElseThrow(() -> new UsernotfoundException("User is not register"));
      
		return user.getRole();
	}

	public Userdto getdatabyemail(String email) {
		
		User finduser= userrepository.findByEmail(email).orElseThrow(() -> new UsernotfoundException("User is not register"));
		
		Userdto ud=new Userdto();
		BeanUtils.copyProperties(finduser, ud);
		
		return ud;
	}

	public int gettheid(String email) {
		// TODO Auto-generated method stub
		User finduser=userrepository.findByEmail(email).orElseThrow(() -> new UsernotfoundException("User is not register"));
	
		return finduser.getId();
	}

	
	
	
}
