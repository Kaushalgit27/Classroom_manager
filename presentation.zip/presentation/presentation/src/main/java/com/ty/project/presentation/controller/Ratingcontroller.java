package com.ty.project.presentation.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ty.project.presentation.entity.Presentation;
import com.ty.project.presentation.entity.Rating;
import com.ty.project.presentation.service.Recordservice;

@Controller
@RequestMapping("/rating")
@CrossOrigin(origins = "http://localhost:3000") 
public class Ratingcontroller {
	
	Recordservice rs;
	
	public Ratingcontroller(Recordservice rs){
		this.rs=rs;
	}
	
	
	//rating the presentation
	@PostMapping("/addingrating")
	public ResponseEntity<String> ratingpresentation( @RequestBody Rating rating, @RequestParam int uid, @RequestParam int pid){
	return	rs.rateThePresentation(rating,uid,pid);
		
	}
	//getting all the rating of particular student
	@GetMapping("/getallrating")
	public ResponseEntity<List<Rating>> getallrating(@RequestParam int uid){
		List<Rating> rat= rs.getoverallrating(uid);
		
		return new ResponseEntity<List<Rating>>(rat, HttpStatus.OK);
		
	}
	
	//getting all the rating of particular student
	@GetMapping("/getallratings")
	public ResponseEntity<Double> getsallratings(@RequestParam int uid) {
	    double rating = rs.getoverallratings(uid);
	    return ResponseEntity.ok(rating);
	}
	
	//getting the presentation with id
	@GetMapping("/getRating")
	public ResponseEntity<Rating> gettherating(@RequestParam int pid){
		Rating rate=rs.gettherating(pid);
		return new ResponseEntity<Rating>(rate, HttpStatus.OK);
	}
	
	

}
