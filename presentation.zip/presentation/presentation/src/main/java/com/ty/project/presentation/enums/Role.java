package com.ty.project.presentation.enums;

public enum Role {
	
	ADMIN,STUDENT

}
