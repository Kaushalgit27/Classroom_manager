package com.ty.project.presentation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.project.presentation.entity.Presentation;
import com.ty.project.presentation.entity.Rating;
import com.ty.project.presentation.entity.User;
import com.ty.project.presentation.exception.PresentationnotFoundException;
import com.ty.project.presentation.exception.RatingException;
import com.ty.project.presentation.exception.UsernotfoundException;
import com.ty.project.presentation.repository.Presentationrepository;
import com.ty.project.presentation.repository.Ratingrepository;
import com.ty.project.presentation.repository.Userrepository;

@Service
public class Recordservice {
	
	Ratingrepository ratingrepo;
	Presentationrepository pr;
	Userrepository ur;
	public Recordservice(Ratingrepository ratingrepo,	Presentationrepository pr,Userrepository ur) {
		this.ratingrepo=ratingrepo;
		this.pr=pr;
		this.ur=ur;
	}

	//inserting the ratings 
//	public  ResponseEntity<String>  rateThePresentation(Rating rating, int uid,int pid) {
//		double total=0;
//		
//		User use=ur.findById(uid).orElseThrow(() -> new UsernotfoundException("User is not register"));
//		Presentation pres=pr.findById(pid).orElseThrow(() -> new PresentationnotFoundException("No presentations found for the given user ID: "));
//	//finding pid and uid are they present in presentation table
//		Optional<Presentation> opt=pr.findByPidAndUser_Id(pid, uid);
//		rating.setTotalScore(total);
//		//finding same user id and pid inside rating table
//		Optional<Rating> roptional=ratingrepo.findByPresentation_PidAndUser_Id(pid, uid);
//		
//		  if(roptional.isPresent()) {
//			  return  new ResponseEntity<String>("The given presentation and id already exist update it ", HttpStatus.BAD_REQUEST);
//		
//		  }
//	
//		if(opt.isPresent()) {
//		 total=rating.getCommunication()+rating.getContent()+rating.getLiveliness()+rating.getUsageProps();
//		rating.setTotalScore(total/4);
//		pres.setPscore(total/4);
//		
//		
//		rating.setUser(use);
//		rating.setPresentation(pres);
//		pr.save(pres);
//		ratingrepo.save(rating);
//		
//		return new ResponseEntity<String>("Rating added for given user id and presentation id", HttpStatus.OK);
//	}else {
//	
//		return  new ResponseEntity<String>("There is no student for given presentation ", HttpStatus.BAD_REQUEST);
//	}
//	
//		
//	}
	
	public ResponseEntity<String> rateThePresentation(Rating rating, int uid, int pid) {
	    double total = 0;

	    // Fetch user by UID
	    User use = ur.findById(uid).orElseThrow(() -> new UsernotfoundException("User is not register"));

	    // Fetch presentation by PID
	    Presentation pres = pr.findById(pid).orElseThrow(() -> new PresentationnotFoundException("No presentations found for the given user ID: "));

	    // Check if the user and presentation exist in the presentation table
	    Optional<Presentation> opt = pr.findByPidAndUser_Id(pid, uid);

	    // Initial total score for rating
	    rating.setTotalScore(total);

	    // Check if a rating already exists for the given user and presentation
	    Optional<Rating> roptional = ratingrepo.findByPresentation_PidAndUser_Id(pid, uid);

	    if (roptional.isPresent()) {
	        // If rating exists, update it
	        Rating existingRating = roptional.get();
	        existingRating.setCommunication(rating.getCommunication());
	        existingRating.setContent(rating.getContent());
	        existingRating.setLiveliness(rating.getLiveliness());
	        existingRating.setUsageProps(rating.getUsageProps());

	        // Calculate the new total score
	        total = existingRating.getCommunication() + existingRating.getContent() + existingRating.getLiveliness() + existingRating.getUsageProps();
	        existingRating.setTotalScore(total / 4);

	        // Update the presentation score
	        pres.setPscore(existingRating.getTotalScore());

	        // Save the updated rating and presentation
	        ratingrepo.save(existingRating);
	        pr.save(pres);
	        
	        
	        //update the score rating in user table
	        List<Presentation> listpresent=pr.findByUser_Id(uid);
	      
	        if(listpresent.isEmpty()==false) {
	        	double totalscore=0;
	        	int count=0;
	        	for(int i=0;i<listpresent.size();i++) {
	        		totalscore=totalscore+listpresent.get(i).getPscore();
	        	    count++;
	        	}
	        	User findtheuser=ur.findById(uid).orElseThrow(() -> new UsernotfoundException("User is not register"));
	        	findtheuser.setUserscore(totalscore/count);
	        	ur.save(findtheuser);
	        	
	        }
	        
	        

	        return new ResponseEntity<String>("Rating updated successfully for the given user id and presentation id", HttpStatus.OK);
	    }

	    // If no rating exists, create a new one
	    if (opt.isPresent()) {
	        total = rating.getCommunication() + rating.getContent() + rating.getLiveliness() + rating.getUsageProps();
	        rating.setTotalScore(total / 4);

	        // Update presentation score
	        pres.setPscore(total / 4);

	        // Set user and presentation for the rating
	        rating.setUser(use);
	        rating.setPresentation(pres);

	        // Save the new rating and presentation
	        pr.save(pres);
	        ratingrepo.save(rating);
	        
	        //update the score rating in user table
	        List<Presentation> listpresent=pr.findByUser_Id(uid);
		      
	        if(listpresent.isEmpty()==false) {
	        	double totalscore=0;
	        	int count=0;
	        	for(int i=0;i<listpresent.size();i++) {
	        		totalscore=totalscore+listpresent.get(i).getPscore();
	        	    count++;
	        	}
	        	User findtheuser=ur.findById(uid).orElseThrow(() -> new UsernotfoundException("User is not register"));
	        	findtheuser.setUserscore(totalscore/count);
	        	ur.save(findtheuser);
	        	
	        }

	        return new ResponseEntity<String>("Rating added for given user id and presentation id", HttpStatus.OK);
	    } else {
	        return new ResponseEntity<String>("There is no student for the given presentation", HttpStatus.BAD_REQUEST);
	    }
	    
	  
	}

	
	

	

	
	//getting over all list of rating

	public List<Rating> getoverallrating( int uid) {
		List<Rating> rate=ratingrepo.findByUser_Id(uid);
		double answer=0;
		
		if(rate.isEmpty()) {
			 throw new RatingException("No presentations found for the given user ID: " + uid);
		}
		for(int i=0;i<rate.size();i++) {
			answer=answer+rate.get(i).getTotalScore();
		}
		
		
		
		return rate;
	}
	
	//getting overall rating
	public double getoverallratings( int uid) {
		int count=0;
		List<Rating> rate=ratingrepo.findByUser_Id(uid);
		double answer=0;
		
		if(rate.isEmpty()) {
			 throw new RatingException("No presentations found for the given user ID: " + uid);
		}
		for(int i=0;i<rate.size();i++) {
			answer=answer+rate.get(i).getTotalScore();
			count++;
		}
		answer=answer/count;
		
		
		
		return answer;
	}
//getting rating by pid
	public Rating gettherating(int pid) {
		Optional<Rating> rate=ratingrepo.findByPresentation_Pid(pid);
		
		return rate.get();
	}

}
