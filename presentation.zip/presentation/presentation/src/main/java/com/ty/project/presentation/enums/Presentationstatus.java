package com.ty.project.presentation.enums;

public enum Presentationstatus {
	ASSIGNED,COMPLETED,ONGOING

}
