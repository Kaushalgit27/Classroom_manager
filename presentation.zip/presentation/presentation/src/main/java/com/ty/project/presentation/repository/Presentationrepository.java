package com.ty.project.presentation.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.project.presentation.entity.Presentation;

public interface Presentationrepository extends  JpaRepository<Presentation,Integer> {

	

	public List<Presentation> findByUser_Id(int uid);
	
	public Optional<Presentation> findByPidAndUser_Id(int pid,int uid);
	


	
}
