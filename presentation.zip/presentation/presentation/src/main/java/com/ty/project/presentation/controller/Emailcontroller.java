package com.ty.project.presentation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ty.project.presentation.service.SendEmailService;



@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class Emailcontroller {
	
	@Autowired
	SendEmailService sendemail;
	
	@PostMapping("/sendEmail")
	public String sendEmail(@RequestParam String email, @RequestParam String body,@RequestParam String subject,@RequestParam String fromEmail) {
		sendemail.sendEmail(email, body ,subject,fromEmail);
		return "sent sucessfully";
		
	}
	

}
