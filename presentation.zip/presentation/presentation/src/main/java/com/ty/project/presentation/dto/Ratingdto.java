package com.ty.project.presentation.dto;

public class Ratingdto {
	
	
	private Integer communication;
	private Integer content;
	private Integer liveliness;
	private Integer usageProps;
	private Double totalScore;
	
	public Integer getCommunication() {
		return communication;
	}
	public void setCommunication(Integer communication) {
		this.communication = communication;
	}
	public Integer getContent() {
		return content;
	}
	public void setContent(Integer content) {
		this.content = content;
	}
	public Integer getLiveliness() {
		return liveliness;
	}
	public void setLiveliness(Integer liveliness) {
		this.liveliness = liveliness;
	}
	public Integer getUsageProps() {
		return usageProps;
	}
	public void setUsageProps(Integer usageProps) {
		this.usageProps = usageProps;
	}
	public Double getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(Double totalScore) {
		this.totalScore = totalScore;
	}
	

	
}
